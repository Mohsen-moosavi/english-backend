exports.errorHandler = (err, req, res, next) => {
  // Codes
};
